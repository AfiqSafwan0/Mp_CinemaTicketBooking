/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cinemax;

/**
 *
 * @author USER
 */
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
public class CinemaX {
    private static final int rows = 5;
    private static final int columns = 5;
    private static boolean[][] seats = new boolean[rows][columns];
    
    private static String selectedMovie;
    private static String selectedExperience;
    private static int numAdults;
    private static int numChildren;
    private static String selectedDate;
    private static String selectedSeats;
    private static double totalCost;
    
    //afiq's part
    public static void main(String[] args) {
        
        //for looping for repeated uses
        boolean exit = false;
        
        //display CinemaX logo
        ImageIcon logo = new ImageIcon("src/CinemaX/logo.png");

        //display movie image based on user selection    
        while (!exit) {
            String[] movies = {"Sheriff: Narko Integriti", "Transformers One", "The Wild Robot"};
            ImageIcon logo1 = new ImageIcon("src/CinemaX/sheriff.jpeg");
            ImageIcon logo2 = new ImageIcon("src/CinemaX/transformers.jpeg");
            ImageIcon logo3 = new ImageIcon("src/CinemaX/wild.jpeg");
            
            //display welcome message and movie selection
            String choice = (String) JOptionPane.showInputDialog(null,
                    "Welcome ☺\nPlease select a movie", "CinemaX", JOptionPane.PLAIN_MESSAGE,
                    logo, movies, movies[0]);
            
            //check if user selected movie
            if (choice != null) {
                selectedMovie = choice;
                ImageIcon movieicon = null;

                if (choice.equals("Sheriff: Narko Integriti")) {
                    movieicon = logo1;
                } else if (choice.equals("Transformers One")) {
                    movieicon = logo2;
                } else if (choice.equals("The Wild Robot")) {
                    movieicon = logo3;
                }

                selectExperience(movieicon);
            } else {
                //message if user press 'cancel'
                JOptionPane.showMessageDialog(null, "No movie selected. Exiting...", "CinemaX", JOptionPane.WARNING_MESSAGE);
                exit = true;
            }
        }
    }
    
    //hurin's part
    public static void selectExperience(ImageIcon movieicon) {

        //define ticket price based on experience
        String max = "25.00", mos = "17.00", nit = "15.00";
        
        //message for user to select an experience
        String message = "Great choice! You've selected : " + selectedMovie +"\n" +
                         "Please select cinema experience:\n" +
                         "1. IMAX = RM " + max + "\n" +
                         "2. Dolby Atmos = RM " + mos + "\n" +
                         "3. Infinity = RM " + nit + "\n" +
                         "4. Return";

        //input dialog to get user's choice
        String put = (String) JOptionPane.showInputDialog(null, message + "\nEnter your choice (1-4):", "CinemaX", JOptionPane.PLAIN_MESSAGE, movieicon, null, null);

        try {
            int pick = Integer.parseInt(put);
            double ticketprice = 0.0;
            
            //determine user's choice of experience and ticket price
            switch (pick) {
                case 1:
                    ticketprice = Double.parseDouble(max);
                    selectedExperience = "IMAX";
                    break;
                case 2:
                    ticketprice = Double.parseDouble(mos);
                    selectedExperience = "Dolby Atmos";
                    break;
                case 3:
                    ticketprice = Double.parseDouble(nit);
                    selectedExperience = "Infinity";
                    break;
                case 4:
                     //handle return to main menu
                    JOptionPane.showMessageDialog(null, "Return to main menu.", "CinemaX", JOptionPane.INFORMATION_MESSAGE);
                    return;
                default:
                    //handle invalid selection
                    JOptionPane.showMessageDialog(null, "Invalid selection. Please choose a number between 1 and 4.", "CinemaX", JOptionPane.ERROR_MESSAGE);
                    return;
            }
            //input for how many adults
            String adultsInput = (String) JOptionPane.showInputDialog(null, "How many adults?", "CinemaX", JOptionPane.PLAIN_MESSAGE);
            numAdults = Integer.parseInt(adultsInput);

            //input for how many children
            String childrenInput = (String) JOptionPane.showInputDialog(null, "How many children? (50% off)", "CinemaX", JOptionPane.PLAIN_MESSAGE);
            numChildren = Integer.parseInt(childrenInput);

            //calculate total cost
            totalCost = (numAdults * ticketprice) + (numChildren * (ticketprice / 2));

            //select date for the movie
            selectDate(movieicon);
        } catch (NumberFormatException e) {
            //handle any number format exceptions (invalid input)
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid number.", "CinemaX", JOptionPane.ERROR_MESSAGE);
        }
    }

    //muhammad's part
    public static void selectDate(ImageIcon movieicon) {
        String[] availableDates = {"8pm / 30 Oct", "9pm / 31 Oct", "10pm / 1 Nov"};//utk menunjukkan pilihan tarikh dan masa utk pilih
        selectedDate = (String) JOptionPane.showInputDialog(null,
                "Choose a time/date:", 
                "Time/Date Selection", 
                JOptionPane.PLAIN_MESSAGE, 
                null, 
                availableDates, 
                availableDates[0]);

        if (selectedDate != null) {//Jika tarikh smua sdh dipilih
            selectSeats(movieicon);//dh pilih tarikh ,terus ke pemilihan tempat duduk
        } else {//mesej ini keluar jika tiada tarikh yg dipilih
            JOptionPane.showMessageDialog(null, "Date selection cancelled. Thank you for using the Cinema Booking System. Goodbye!");
        }
    }

    public static void selectSeats(ImageIcon movieicon) {
        while (true) {
            String seatDisplay = displaySeats();
            String input = JOptionPane.showInputDialog(null, 
                    seatDisplay + "\nChoose " + (numAdults + numChildren) + " seats (e.g., A1, B2) separated with space or type 'exit' to finish:");

            if (input == null || input.equalsIgnoreCase("exit")) {
                JOptionPane.showMessageDialog(null, "Thank you for using the Cinema Booking System. Goodbye!");
                return;
            }

            String[] selectedSeatsArray = input.split(" "); 
            StringBuilder successMessage = new StringBuilder("Successfully booked the following seats:\n");
            int successfullyBooked = 0;

            for (String seat : selectedSeatsArray) {
                seat = seat.trim(); 
                int[] seatPosition = seatname(seat.toUpperCase());

                if (seatPosition == null || seats[seatPosition[0]][seatPosition[1]]) {
                    
                    successMessage.append("Seat " + seat + " is invalid or already booked. Please choose another.\n");
                } else {
                    seats[seatPosition[0]][seatPosition[1]] = true;
                    successMessage.append(seat + " ");
                    successfullyBooked++;
                }
            }

            if (successfullyBooked > 0) {
                selectedSeats = input;
                JOptionPane.showMessageDialog(null, successMessage.toString(), "Booking Confirmation", JOptionPane.PLAIN_MESSAGE);
                Recheck(movieicon); // Call Recheck before payment
                processPaymentSelection(totalCost);
                break; 
            } else {
                JOptionPane.showMessageDialog(null, "No seats were booked. Please try again.");
            }
        }
    }

    private static String displaySeats() {//method utk display seat yg available
    StringBuilder seatDisplay = new StringBuilder("Current seat availability:\n    1   2   3   4   5\n"); // Column headers
    char rowLabel = 'A';

    for (int i = 0; i < rows; i++) {//ini utk tnjuk setiap baris 
        seatDisplay.append(rowLabel).append("  "); // Row label
        for (int j = 0; j < columns; j++) {
            String seatLabel = rowLabel + String.valueOf(j + 1);//utk hasilkan label tempat duduk 
            if (seats[i][j]) {
                seatDisplay.append("[").append(seatLabel).append("] ");
            } else {//jika seat ksonog,kurungan kosong akan dipaparkan
                seatDisplay.append("[ ] ");
            }
        }
        rowLabel++;//ke label baris seterusnya
        seatDisplay.append("\n");
    }
    return seatDisplay.toString();
}


    private static int[] seatname(String seatLabel) {//method ut tukar label tempat duduk
        if (seatLabel.length() < 2 || seatLabel.length() > 3) {//length utk label tempat duduk
            return null;
        }
        
        char rowChar = seatLabel.charAt(0);
        int column = Integer.parseInt(seatLabel.substring(1)) - 1;

        if (rowChar < 'A' || rowChar > 'E' || column < 0 || column >= columns) {//utk check baris dgn lajur dalam lingkungan
            return null;
        }

        int row = rowChar - 'A';//convert a char to  an integer
        return new int[] {row, column};
    }

    
    //afiq's part
    //basically to summarize all user choices 
    public static void Recheck(ImageIcon movieicon) {
        JOptionPane.showMessageDialog(null, 
                "Total cost: RM " + totalCost + "\n"+
                "What you chose:\n" +
                "Movie                     : " + selectedMovie + "\n" +
                "Time/Date              : " + selectedDate + "\n" +
                "Movie Experience: " + selectedExperience + "\n" +
                "Number of People : " + (numAdults + numChildren) + "\n" +
                "Seats                       : " + selectedSeats, 
                "Recheck Your Choices", JOptionPane.PLAIN_MESSAGE);        
    }

    //adam's part
    public static void processPaymentSelection(double totalCost) {
        while (true){
    try {
        //display payment option
        String paymentMessage = "Please select your payment method:\n" +
                                "1. FPX\n" +
                                "2. Credit/Debit Card\n" +
                                "3. Cancel Payment";
        //user kena pilih                         
        String paymentInput = JOptionPane.showInputDialog(null, paymentMessage + "\nEnter your choice (1-3):", "CinemaX - Payment", JOptionPane.PLAIN_MESSAGE);
        
        if (paymentInput == null){
            JOptionPane.showMessageDialog(null, "Payment canceled. Returning to the main menu.", "Payment Canceled", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int paymentChoice = Integer.parseInt(paymentInput);

        switch (paymentChoice) {
            case 1:
                //kalau user pilih FPX payment
                JOptionPane.showMessageDialog(null, "You selected FPX. Processing payment for RM " + totalCost, "Payment Confirmation", JOptionPane.PLAIN_MESSAGE);
                break;
            case 2:
                //kalau user pilih Credit/Debit card Payment
                JOptionPane.showMessageDialog(null, "You selected Credit/Debit Card. Processing payment for RM " + totalCost, "Payment Confirmation", JOptionPane.PLAIN_MESSAGE);
                break;
            case 3:
                //kalau user nk cancel payment
                JOptionPane.showMessageDialog(null, "Payment canceled. Returning to the main menu.", "Payment Canceled", JOptionPane.WARNING_MESSAGE);
                return;
            default:
                //kalau user salah masuk choice
                JOptionPane.showMessageDialog(null, "Invalid payment choice. Please choose 1, 2, or 3.", "Payment Error", JOptionPane.ERROR_MESSAGE);
                continue;
        }
        // display payment success
        JOptionPane.showMessageDialog(null, "Payment successful! Thank you for your booking.", "Payment Successful", JOptionPane.PLAIN_MESSAGE);
        // tanya user kalau nak buat booking lain 
        int response = JOptionPane.showConfirmDialog(null, "Would you like to make another booking?", "Continue Booking", JOptionPane.YES_NO_OPTION);
        if (response == JOptionPane.YES_OPTION) {
            main(null); // restart booking process by calling method
        } else {
            // exit apps kalau user tak nak booking lagi
            JOptionPane.showMessageDialog(null, "Thank you for using the Cinema Booking System. Goodbye!", "Exit", JOptionPane.PLAIN_MESSAGE);
            System.exit(0);
        }
    } catch (NumberFormatException e) {
        // Handle cases where user input is not a number
        JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
 }}